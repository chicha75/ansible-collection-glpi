#!/bin/bash
DIR=%DIR%
$DIR/env/bin/python $DIR/glpi-api.py "$@"
